package com.capgemini.mps.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.capgemini.mps.exception.MobilePurchaseException;
import com.capgemini.mps.util.DBConnection;

public class PurchaseDaoImpl implements IPurchaseDAO {

	private static Logger daoLogger=Logger.getLogger(PurchaseDaoImpl.class);
	@Override
	public Integer addPurchaseDetails(String name, String emailId,Long phoneNumber, Integer mobileId)
					throws MobilePurchaseException {
		try(
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.ADD_PURCHASE_DETAILS);
			Statement statement=connection.createStatement();
		){
			preparedStatement.setString(1, name);
			preparedStatement.setString(2, emailId);
			preparedStatement.setLong(3, phoneNumber);
			preparedStatement.setInt(4, mobileId);
			int n = preparedStatement.executeUpdate();
			if(n>0){
				daoLogger.info("1 row added to purchase details table");
				
				new MobileDaoImpl().updateMobileQuantity(mobileId,1);
				ResultSet resultSet=statement.executeQuery(QueryMapper.RETRIEVE_PURCHASEID);
				if(resultSet.next()){
					Integer purchaseId=resultSet.getInt(1);
					return purchaseId;	
				}else{
					return null;
				}
			}else{
				daoLogger.info("Unable to insert purchase details");
				throw new MobilePurchaseException("Unable to add purchase details");
			}
		}catch(SQLException e){
			daoLogger.info("technical error");
			throw new MobilePurchaseException("Technical error");
		}
		
	}


}
