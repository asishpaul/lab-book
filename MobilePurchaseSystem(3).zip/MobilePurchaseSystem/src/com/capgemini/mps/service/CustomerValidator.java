package com.capgemini.mps.service;
import java.util.regex.Pattern;
/**
 * 
 * @author arindam_bhowmick
 * This class validates the data fields of Customer class
 */
public class CustomerValidator {
	/**
	 * @param customer
	 * @return false if customer name is not in text 
	 */
	public Boolean isValidCustomerName(String name){
		String regex="^[A-Z]{1}[a-zA-Z\\s]{0,19}$";
		return Pattern.matches(regex,name);
	}
	/**
	 * 
	 * @param customer
	 * @return true if email is valid else return false.
	 * email validity:
	 * 1.email begins with either digits or alphabets followed one @ symbol followed by 2 or 3 characters
	 * followed by dot(.)operator followed by 2 characters is optional.
	 */
	
	public Boolean isValidEmail(String emailId){
		String regex="^[a-zA-Z0-9._]+[@][a-zA-Z]+[.][a-zA-Z]{2,3}$"; 
		return Pattern.matches(regex,emailId);
	}
	/**
	 * 
	 * @param customer
	 * @return true if mobile number is 10 digit else return false.
	 */
	
	public Boolean isValidPhoneNumber(Long phoneNumber){
		String mobile=phoneNumber.toString();
		String regex="^[1-9][0-9]{9}$";
		return Pattern.matches(regex,mobile);
	}		
}
