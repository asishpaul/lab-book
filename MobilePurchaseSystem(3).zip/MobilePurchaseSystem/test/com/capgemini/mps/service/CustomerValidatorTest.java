package com.capgemini.mps.service;

import static org.junit.Assert.*;

import org.junit.Test;

public class CustomerValidatorTest {

	@Test
	public void testIsValidCustomerName() {
		assertTrue(new CustomerValidator().isValidCustomerName("Arindam Bhowmick"));
	}
	
	@Test
	public void testIsNotValidCustomerName() {
		assertFalse(new CustomerValidator().isValidCustomerName("Arindam Bhowmickxxxxxxxxxxxxx"));
	}
	@Test
	public void testIsValidEmail() {
		assertTrue(new CustomerValidator().isValidEmail("ravi@m.com"));
	}
	@Test
	public void testIsNotValidEmail() {
		assertFalse(new CustomerValidator().isValidEmail("Arin96@gmail.com"));
	}
	@Test
	public void testIsValidPhoneNumber() {
		assertTrue(new CustomerValidator().isValidPhoneNumber(9876543210L));
	}

}
