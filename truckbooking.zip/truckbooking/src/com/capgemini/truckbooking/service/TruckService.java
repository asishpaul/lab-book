package com.capgemini.truckbooking.service;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.List;

import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.dao.ITruckDao;
import com.capgemini.truckbooking.dao.TruckDao;
import com.capgemini.truckbooking.exception.BookingException;

public class TruckService implements ITruckService{
	
	ITruckDao truckDAO=new TruckDao();
	
	@Override
	public List<TruckBean> retrieveTruckDetails() throws BookingException {
		
		List<TruckBean> truckDetails=truckDAO.retrieveTruckDetails();
		return truckDetails;
	}

	@Override
	public Integer bookTrucks(String custId, long custMobile, int truckId, int noOfTrucks,LocalDate dateOfTransport)
			throws BookingException {
		
		
		try {
			Integer BookingId=truckDAO.bookTrucks(custId,custMobile,truckId,noOfTrucks,dateOfTransport);
			if(BookingId>0) {
				return BookingId;
			}
			else {
				return null;
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	

}
