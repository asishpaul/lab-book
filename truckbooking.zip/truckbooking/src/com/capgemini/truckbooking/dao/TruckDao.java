package com.capgemini.truckbooking.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.BookingException;
import com.capgemini.truckbooking.util.DBConnection;

public class TruckDao implements ITruckDao {

	@Override
	public List<TruckBean> retrieveTruckDetails() throws BookingException {

		int Count=0;
		try(Connection connection=DBConnection.getConnection();
			Statement statement=connection.createStatement();
				){
			
			ResultSet resultSet=statement.executeQuery(QueryMapper.DISPLAY_TRUCK);
			List<TruckBean> truckList=new ArrayList<>();
			while(resultSet.next()) {
				Count++;
				TruckBean details=new TruckBean();
				populate(details,resultSet);
				truckList.add(details);
			}
			if(Count!=0) {
				return truckList;
			}
			else {
				return null;
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return null;

	}

	private void populate(TruckBean details, ResultSet resultSet) throws SQLException {
		
		details.setTruckID(resultSet.getInt("truckId"));
		details.setTruckType(resultSet.getString("truckType"));
		details.setOrigin(resultSet.getString("origin"));
		details.setDestination(resultSet.getString("destination"));
		details.setCharges(resultSet.getFloat("charges"));
		details.setAvilableNos(resultSet.getInt("availableNos"));
		
	}


	/*@Override
	public int getBookingId() throws BookingException {

	}*/

	
	/*@Override
	public int getBookingId() throws BookingException {
		// TODO Auto-generated method stub
		return 0;
	}*/

	@Override
	public Integer bookTrucks(String custId, long custMobile, int truckId, int noOfTrucks, LocalDate dateOfTransport)
			throws BookingException {
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.BOOKING_INSERT);
				Statement statement=connection.createStatement();
				){
			Date sqldate=Date.valueOf(dateOfTransport);
			preparedStatement.setString(1, custId);
			preparedStatement.setLong(2, custMobile);
			preparedStatement.setInt(3, truckId);
			preparedStatement.setInt(4, noOfTrucks);
			preparedStatement.setDate(5, sqldate);
			
			int n=preparedStatement.executeUpdate();
			System.out.println("Booking Successfull");
			if(n>0) {
				
				ResultSet resultSet=statement.executeQuery(QueryMapper.BOOKING_NO);
				if(resultSet.next()) {
					Integer BookingId=resultSet.getInt(1);
					System.out.println("Booking Id:"+BookingId);
					return BookingId;
				}
				else {
					return null;
				}
			}
			else
			{
				return null;
			}
			
	}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return null;

}

	/*@Override
	public int getBookingId() throws BookingException {
		// TODO Auto-generated method stub
		return 0;
	}*/
}