package com.capgemini.truckbooking.client;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.service.ITruckService;
import com.capgemini.truckbooking.service.TruckService;

public class BookingClient {

	private static Scanner scanner=new Scanner(System.in);
	private static TruckBean truckDetails=new TruckBean();
	private static ITruckService truckService=new TruckService();
	
	
	public static void main(String[] args) {
		
		
		int option;
		while(true) {
			
			System.out.println();
			System.out.println("Truck Booking System");
			System.out.println("------------");
			System.out.println("1.Book Truck");
			System.out.println("2.Exit");
			System.out.println();
			System.out.println("Enter option: ");
			
			option=scanner.nextInt();
			
			try {
				switch(option) {
				
				case 1:
					System.out.println("Enter customer id: ");
					String custId=scanner.nextLine();
					scanner.nextLine();
					List<TruckBean> truckDetails=truckService.retrieveTruckDetails();
					Iterator<TruckBean> iterator=truckDetails.iterator();
					while(iterator.hasNext()) {
						System.out.println(iterator.next());
					}
					System.out.println("");
					System.out.println("---------------------------");
					System.out.println("Please enter truckId to book truck: ");
					int truckId=scanner.nextInt();
					
					System.out.println("Enter number of truck to be booked(only numeric value): ");
					int noOfTrucks=scanner.nextInt();
					System.out.println("Enter Customer Mobile:");
					long custMobile=scanner.nextLong();
					System.out.println("Enter date of transaction(DD-MM-YYYY): ");
					String date1="2018-10-29";
					LocalDate dateOfTransport=LocalDate.parse(date1);
					System.out.println(dateOfTransport);
					//String dateOfTransport=scanner.nextLine();
					//SimpleDateFormat =new SimpleDateFormat("dd-mm-yyyy");
					
					//Date dateOfTransport=(Date) new SimpleDateFormat("dd-MM-yyyy").parse(bookDate);
					//scanner.nextLine();
					
					Integer BookingId=truckService.bookTrucks(custId, custMobile, truckId, noOfTrucks,dateOfTransport);
					
					break;
				case 2:
					System.exit(0);
				}
				
				
			}
			
			catch(Exception e) {
				e.printStackTrace();
			}
			
		}
		

	}

}
