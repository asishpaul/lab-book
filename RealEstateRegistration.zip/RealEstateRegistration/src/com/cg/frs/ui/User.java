package com.cg.frs.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.frs.dao.Validator;
import com.cg.frs.dto.FlatOwner;
import com.cg.frs.service.FlatRegistrationServiceImpl;
import com.cg.frs.service.IFlatRegistrationService;

public class User {

	private static Scanner scanner=new Scanner(System.in);
	private static FlatOwner ownerDetails = new FlatOwner();
	private static IFlatRegistrationService registrationDetails = new FlatRegistrationServiceImpl();
	private static Validator validator = new Validator();

	public static void main(String[] args) {

		int option;
		while(true){

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   Real Estate Registration Service ");
			System.out.println("_______________________________\n");

			System.out.println("1.Register Flat ");
			System.out.println("2.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");

			option = scanner.nextInt();

			try {

				switch (option) {
				case 1:
					System.out.println("Available Owners: ");
					List<FlatOwner> ownerDetails=registrationDetails.getOwnerDetails();
					Iterator<FlatOwner> iterator= ownerDetails.iterator();
					while(iterator.hasNext()){
						System.out.println(iterator.next());
					} 
					System.out.println("");
					System.out.println("---------------------------");
					System.out.println("Please enter your owner id from above list: ");
					int ownerId=scanner.nextInt();
					System.out.println("Select flat type(1-1BHK, 2-2BHK: ");
					int flatType=scanner.nextInt();
					System.out.println("Enter Flat Area: ");
					int flatArea=scanner.nextInt();
					System.out.println("Enter desired rent amount RS: ");
					int rentAmount=scanner.nextInt();
					System.out.println("Enter depired deposit amount RS: ");
					int desireAmount=scanner.nextInt();

						
							if(validator.isValidDeposit(desireAmount,rentAmount)){


								Integer FlatRegNo=registrationDetails.addRegistrationDetails(ownerId,flatType,flatArea,rentAmount,desireAmount);
							}
							else{
								System.out.println("Enter valid desired deposit amount...");
							}
					
					
					break;
				case 2:
					System.exit(0);
					break;

				}			
			}
			catch(Exception e){

			}

		}

	}
}
