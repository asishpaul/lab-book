package com.cg.frs.dao;

import java.util.regex.Pattern;

public class Validator {
	public Validator(){
	}
	


	public Boolean isValidDeposit(Integer deposit, Integer rent){
	
		
		if(deposit>rent){
			return true;
		}


		return false;
	}

	public Boolean isValidFlatType(Integer flatType){
		String regex3="^[0-9]{1}$";
		String flatType1=Integer.toString(flatType);



		return Pattern.matches(regex3,flatType1);

	}
	
	public Boolean isValidOwnerName(String name){
		String regex="^[A-Z]{1}[a-zA-Z\\s]$";
		return Pattern.matches(regex,name);
	}

}

