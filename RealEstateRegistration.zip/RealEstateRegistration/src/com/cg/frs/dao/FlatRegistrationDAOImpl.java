package com.cg.frs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.trg.exception.FlatException;
import com.capgemini.trg.util.DBConnection;
import com.cg.frs.dto.FlatOwner;

public class FlatRegistrationDAOImpl implements IFlatRegistrationDAO {

	private static Logger daoLogger=Logger.getLogger(FlatRegistrationDAOImpl.class);
	@Override
	public List<FlatOwner> getOwnerDetails() throws FlatException {


int ownerCount = 0;
		
		try(Connection connection = DBConnection.getConnection();
				Statement statement = connection.createStatement();
				){
			ResultSet resultSet = statement.executeQuery(QueryMapper.DISPLAY_FLAT);
			List<FlatOwner> ownerList = new ArrayList<>();
			while(resultSet.next()){
				
				ownerCount++;
				FlatOwner owner = new FlatOwner();
				populateOwner(owner,resultSet);
				ownerList.add(owner);
				
			}
			if(ownerCount!=0){
				
				return ownerList;
			}else{
				
				daoLogger.info("Can't fech ownerName");
				return null;
			}
		}catch(SQLException e){
			daoLogger.error(e);
			System.out.println(e.getMessage());
		}
		
		return null;
		
	}

	private void populateOwner(FlatOwner owner, ResultSet resultSet) throws SQLException {
		
		owner.setOwnerId(resultSet.getInt("owner_id"));
		owner.setOwnerName(resultSet.getString("owner_name"));
		owner.setMobile(resultSet.getString("mobile"));
		
	}

	@Override
	public Integer addRegistrationDetails(Integer ownerId, Integer flatType,
			Integer FlatArea, Integer rentAmount, Integer depositAmount)
			throws FlatException {
				
		
		try(
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.BOOKING_INSERT);
				Statement statement = connection.createStatement();
				){
			System.out.println("im in");
			preparedStatement.setInt(1, ownerId);
			preparedStatement.setInt(2,flatType);
			preparedStatement.setInt(3, FlatArea);
			preparedStatement.setInt(4, rentAmount);
			preparedStatement.setInt(5, depositAmount);
			
			int n=preparedStatement.executeUpdate();
			System.out.println("im excuting");
			if(n>0){
				ResultSet resultSet = statement.executeQuery(QueryMapper.FLAT_NO);
				if(resultSet.next()){
					Integer FlatRegNo = resultSet.getInt(1);
					return FlatRegNo;
				}
				else{
					return null;
				}
			}
			else{
				return null;
			}
		}catch(SQLException e){
			daoLogger.error(e);
			throw new FlatException("Technical Error...");
			
		}
		
		
	}

	
}
