package com.cg.frs.dao;

public interface QueryMapper {

	public static final String DISPLAY_FLAT="select * from flat_owners";
	public static final String BOOKING_INSERT="INSERT into flat_registration values(flat_seq.NEXTVAL,?,?,?,?,?)";
	public static final String OWNER_CHECK="SELECT owner_id from flat_owners where owner_id=?";
	public static final String FLAT_NO="SELECT flat_seq.CURRVAL from dual";
}
