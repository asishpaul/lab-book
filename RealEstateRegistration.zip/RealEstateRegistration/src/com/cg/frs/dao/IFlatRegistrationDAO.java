package com.cg.frs.dao;

import java.util.List;

import com.capgemini.trg.exception.FlatException;
import com.cg.frs.dto.FlatOwner;

public interface IFlatRegistrationDAO {

	public abstract List<FlatOwner> getOwnerDetails() throws FlatException;
	public abstract Integer addRegistrationDetails(Integer ownerId,Integer flatType,Integer FlatArea,Integer rentAmount,Integer depositAmount)throws FlatException; 

}
