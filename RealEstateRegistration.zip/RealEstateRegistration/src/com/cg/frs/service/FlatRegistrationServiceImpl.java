package com.cg.frs.service;

import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.trg.exception.FlatException;
import com.cg.frs.dao.FlatRegistrationDAOImpl;
import com.cg.frs.dao.IFlatRegistrationDAO;
import com.cg.frs.dto.FlatOwner;

public class FlatRegistrationServiceImpl implements IFlatRegistrationService{

	private IFlatRegistrationDAO registrationDAO=new FlatRegistrationDAOImpl();
	private static Logger myUILogger=Logger.getLogger(FlatRegistrationServiceImpl.class);
	private String name=new FlatOwner().getOwnerName();
	
	@Override
	public List<FlatOwner> getOwnerDetails() throws FlatException {
		
		List<FlatOwner> ownerDetails=  registrationDAO.getOwnerDetails();
		return ownerDetails;
		
	}

	@Override
	public Integer addRegistrationDetails(Integer ownerId, Integer flatType,
			Integer FlatArea, Integer rentAmount, Integer depositAmount)
			throws FlatException {
		try{
			Integer FlatRegNo =registrationDAO.addRegistrationDetails(ownerId, flatType, FlatArea, rentAmount,depositAmount);
			
			if(FlatRegNo>0){
			return FlatRegNo;
			}
			else{
				return null;
			}
			}catch(Exception e){
				myUILogger.error(e);
				e.printStackTrace();
			}
		return null;
		

	}
	

	
}
