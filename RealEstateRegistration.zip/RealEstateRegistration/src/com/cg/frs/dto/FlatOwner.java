package com.cg.frs.dto;

public class FlatOwner {

	
	private Integer ownerId;
	private String ownerName;
	private String mobile;
	
public FlatOwner() {
		
	}

public FlatOwner(Integer ownerId, String ownerName, String mobile) {
	super();
	this.ownerId = ownerId;
	this.ownerName = ownerName;
	this.mobile = mobile;
}

public Integer getOwnerId() {
	return ownerId;
}

public void setOwnerId(Integer ownerId) {
	this.ownerId = ownerId;
}

public String getOwnerName() {
	return ownerName;
}

public void setOwnerName(String ownerName) {
	this.ownerName = ownerName;
}

public String getMobile() {
	return mobile;
}

public void setMobile(String mobile) {
	this.mobile = mobile;
}

@Override
public String toString() {
	return "FlatOwner [ownerId=" + ownerId + ", ownerName=" + ownerName
			+ ", mobile=" + mobile + "]";
}



}
