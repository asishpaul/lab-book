package com.cg.frs.dto;

public class FlatRegistration {

	private Integer flatRegNo;
	private Integer ownerId;
	private Integer flatType;
	private Integer rentAmount;
	private Integer depositAmount;
	
	public FlatRegistration(){
		
	}

	public FlatRegistration(Integer flatRegNo, Integer ownerId,
			Integer flatType, Integer rentAmount, Integer depositAmount) {
		super();
		this.flatRegNo = flatRegNo;
		this.ownerId = ownerId;
		this.flatType = flatType;
		this.rentAmount = rentAmount;
		this.depositAmount = depositAmount;
	}

	public Integer getFlatRegNo() {
		return flatRegNo;
	}

	public void setFlatRegNo(Integer flatRegNo) {
		this.flatRegNo = flatRegNo;
	}

	public Integer getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(Integer ownerId) {
		this.ownerId = ownerId;
	}

	public Integer getFlatType() {
		return flatType;
	}

	public void setFlatType(Integer flatType) {
		this.flatType = flatType;
	}

	public Integer getRentAmount() {
		return rentAmount;
	}

	public void setRentAmount(Integer rentAmount) {
		this.rentAmount = rentAmount;
	}

	public Integer getDepositAmount() {
		return depositAmount;
	}

	public void setDepositAmount(Integer depositAmount) {
		this.depositAmount = depositAmount;
	}

	@Override
	public String toString() {
		return "FlatRegistration [flatRegNo=" + flatRegNo + ", ownerId="
				+ ownerId + ", flatType=" + flatType + ", rentAmount="
				+ rentAmount + ", depositAmount=" + depositAmount + "]";
	}
	
	
}
