package com.cg.frs.dao;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.cg.frs.dao.Validator;

public class FlatRegistrationDAOImplTest {

	@Test
	public void testGetOwnerDetails() {
		assertTrue(new Validator().isValidOwnerName("Asish paul"));
	}
	@Test
	public void testAddRegistrationDetails() {
		assertTrue(new Validator().isValidDeposit(5000));
	}

}
