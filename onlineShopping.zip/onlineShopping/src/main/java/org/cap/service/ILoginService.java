package org.cap.service;

import org.cap.model.BusRequest;
import org.cap.model.LoginBean;

public interface ILoginService {
	public boolean isValidLogin(LoginBean loginBean);
	public BusRequest createRequest(BusRequest passRequestBean);

}
