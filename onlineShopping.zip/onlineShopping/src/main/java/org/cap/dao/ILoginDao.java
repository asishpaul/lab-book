package org.cap.dao;

import org.cap.model.BusRequest;
import org.cap.model.LoginBean;

public interface ILoginDao {
	public abstract boolean isValidLogin(LoginBean loginBean);

	public abstract BusRequest createRequest(BusRequest passRequestBean);
}
