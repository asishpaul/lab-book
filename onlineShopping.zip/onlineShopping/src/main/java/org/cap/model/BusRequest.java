package org.cap.model;

import java.time.LocalDate;
import java.time.LocalTime;

public class BusRequest {
	
	private int requestId;
	private String employeeID;
	private String firstName;
	private String lastName;
	private String gender;
	private String address;
	private LocalDate dateOfjoining;
	private String emailId;
	private String location;
	private String pickUpLocation;
	private LocalTime pickUpTime;
	private String designation;
	
	public BusRequest() {
		super();
	}
	
	public BusRequest(int requestId, String employeeID, String firstName, String lastName, String gender,
			String address, LocalDate dateOfjoining, String emailId, String location, String pickUpLocation,
			LocalTime pickUpTime, String designation) {
		super();
		this.requestId = requestId;
		this.employeeID = employeeID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.address = address;
		this.dateOfjoining = dateOfjoining;
		this.emailId = emailId;
		this.location = location;
		this.pickUpLocation = pickUpLocation;
		this.pickUpTime = pickUpTime;
		this.designation = designation;
	}



	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public String getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public LocalDate getDateOfjoining() {
		return dateOfjoining;
	}

	public void setDateOfjoining(LocalDate dateOfjoining) {
		this.dateOfjoining = dateOfjoining;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getPickUpLocation() {
		return pickUpLocation;
	}

	public void setPickUpLocation(String pickUpLocation) {
		this.pickUpLocation = pickUpLocation;
	}

	public LocalTime getPickUpTime() {
		return pickUpTime;
	}

	public void setPickUpTime(LocalTime pickUpTime) {
		this.pickUpTime = pickUpTime;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}
	
	
	
	
}
