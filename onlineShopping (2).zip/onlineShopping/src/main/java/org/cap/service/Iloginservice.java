package org.cap.service;

import org.cap.model.LoginBean;

public interface ILoginService {
	public abstract Boolean isValidLogin(LoginBean loginBean);
}
